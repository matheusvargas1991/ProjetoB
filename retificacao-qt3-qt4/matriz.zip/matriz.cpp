#include <iostream.h>
#include <stdlib.h>
#include <math.h>
#include "matriz.h"
//Para exibir graficamente
#include <qtable.h>
#include <qstring.h>


//IMPLEMENTACOES

matriz::matriz(int linha, int coluna)
{
	int i;
	lin = linha;
	col = coluna;
	m = new long double*[lin];
	for (i=0;i<lin;i++)
		m[i] = new long double[col];
}

//matriz::~matriz()  {	delete m;  }

void matriz::atribui(int linha,int coluna,long double val)
{
	m[linha][coluna] = val;
}

void matriz::show()
{
	int i,j;
	for (i=0;i<lin;i++)
	{
		for (j=0;j<col;j++)
		{
			cout << m[i][j] << " ";
			if (j == (col-1)) cout << endl;
		}
	}
}

void matriz::fillrand(int lim)
{
	int i,j;
	srand(time(NULL));
	for (i=0;i<lin;i++)
	{
		for (j=0;j<col;j++)
		{
			m[i][j] = floor(rand() % lim);
		}
	}
}

void matriz::identidade(void)
{
	int i,j;
	if (lin == col)
	{
	  for (i=0;i<lin;i++)
	  {
	     for (j=0;j<col;j++)
	     {
	       if (i == j) 
	       {
	          m[i][j] = 1;
	       }  
	       else 
	       {
	          m[i][j] = 0;
	       }
	     }  
	  }     
	}       
	else
	{
	     cout << "Impossivel criar identidade";
	}     
}

matriz matriz::produto(matriz m1)
{	
	int i,j,k;
	matriz prod(lin,m1.col);

	if (col == m1.lin)
	{		
		for (i=0;i<lin;i++)	  //Percorre linhas da 1 matriz
		{      				
			for (k=0;k<m1.col;k++)  //Percorre colunas da 2 matriz
			{
				prod.m[i][k]=0;
				for (j=0;j<col;j++)
				{
					prod.m[i][k]=prod.m[i][k]+m[i][j]*m1.m[j][k];
				}
			}
		}
		return(prod);
	}
	else
	{
		cout << "Impossivel multiplicar";		
	}
}

matriz matriz::transp(void)
{
	int i,j;
	matriz transposta(col,lin);
	for (i=0;i<lin;i++)
	{
		for (j=0;j<col;j++)
		{
			transposta.m[j][i] = m[i][j];
		}
	}
	return transposta;

}

matriz matriz::copia(void)
{
	int i,j;
	matriz clone(lin,col);
	for (i=0;i<lin;i++)
	{
		for (j=0;j<col;j++)
		{
			clone.m[i][j] = m[i][j];
		}
	}
	return clone;
}

matriz matriz::inversa(int size)
{
	int i,j,k,l;	//this function inv.merts a square matrix (of course)
	long double det=1;   //M, having a (size X size) size.
	long double p,c,x;
	matriz inv(size,size);
	matriz mat(lin,col);
	mat = copia();
	for (i=0;i<size;i++)
		{
		for (j=0;j<size;j++)
			{
			if (i==j) inv.m[i][j]=1;
			else inv.m[i][j]=0;
			}
		}
	i=0;
	while ((i<size)&&(det!=0))
		{
		c=mat.m[i][i];
		l=i;
		for (k=i+1;k<size;k++)
			{
			if (abs(c)<abs(m[k][i]))
				{
				c=mat.m[k][i];
				l=k;
				}
			}
		if (l!=i)
			{
			det = det*(-1);
			for (j=0;j<size;j++)
				{
				x=mat.m[i][j];
				mat.m[i][j]=mat.m[l][j];
				mat.m[l][j]=x;
				x=inv.m[i][j];
				inv.m[i][j]=inv.m[l][j];
				inv.m[l][j]=x;
				}
			}
		p=mat.m[i][i];
		det=det*p;
		if (p!=0)
			{
			for(j=0;j<size;j++)
				{
				mat.m[i][j]=mat.m[i][j]/p;
				inv.m[i][j]=inv.m[i][j]/p;
				}
			for(k=0;k<size;k++)
				{
				if (k!=i)
					{
					p=mat.m[k][i];
					for(j=0;j<size;j++)
						{
						mat.m[k][j]=mat.m[k][j]-p*mat.m[i][j];
						inv.m[k][j]=inv.m[k][j]-p*inv.m[i][j];
						}
					}
				}
			i++;
			}
		}
	if (det==0) cout << "Matriz nao e inversivel!";
	return(inv);

}

void matriz::namao()
{
	int i,j;
	cout << "Preenchendo a matriz" << nome;
	for (i=0;i<lin;i++)
	{
		for (j=0;j<col;j++)
		{
			cout << "\nInforme o valor da posicao" << i << " x " << j << "\n";
			cin >> m[i][j];
		}
	}
}

long double matriz::valor(int linha,int coluna)
{
	return m[linha][coluna];
}

int matriz::maxlin()
{
	return lin;
}
int matriz::maxcol()
{
	return col;
}

void matriz::showGui(QTable *tab)
{
	int i,j;
	tab->setNumRows(lin);
	tab->setNumCols(col);
	QString *str = new QString();

	for (i=0;i<lin;i++)
	{
		for (j=0;j<col;j++)
		{
			tab->setText(i,j,str->number(double(m[i][j])));
		}
	}
}

